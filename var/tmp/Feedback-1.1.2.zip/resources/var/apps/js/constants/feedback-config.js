App.constant('FEEDBACK_CONFIG', {
	max: 5
});
