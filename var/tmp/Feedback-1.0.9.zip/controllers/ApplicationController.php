<?php

class Feedback_ApplicationController extends Application_Controller_Default
{
}